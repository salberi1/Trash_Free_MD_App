export const colors = {
  colors: {
    Chesapeake_Teal: '#afd8c9',
    City_Blue: '#68b5b3',
    Navy: '#215060',
    Autumn: '#d28952',
    Moss_Green: '#9ab880', 
    Sunflower: '#efca66',

  }
}